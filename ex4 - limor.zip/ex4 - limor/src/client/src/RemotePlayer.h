/**
 * Limor Levi 308142389
 * Orel Israeli 204225148
 */

#ifndef REMOTEPLAYER_H
#define REMOTEPLAYER_H


#include "Player.h"

class RemotePlayer : public Player {

public :

    /**
     * Constructor
     * @param type - the type of the player, X or O
     */
    RemotePlayer(enum Type type);
};


#endif //REMOTEPLAYER_H
