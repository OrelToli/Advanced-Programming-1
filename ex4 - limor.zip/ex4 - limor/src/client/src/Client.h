/**
 * Limor Levi 308142389
 * Orel Israeli 204225148
 */

#ifndef CLIENT_H
#define CLIENT_H
#include <unistd.h>
#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fstream>

using namespace std;
class Client {

public:
    /**
     * @name : Client
     * @parameters : no parameters
     * @return : the function creates new instance of Client object
     **/
    Client();


    /**
     * @name : connectToServer
     * @parameters : no parameters
     * @return : the function connects to the server of the game
     **/
    void connectToServer();


    /**
     * @name : sendMove
     * @parameters : the last move in the game
     * @return : the function writes the move to the server
     **/
    void sendMove(int* move);


    /**
     * @name : getPlayerType
     * @parameters : no parameters
     * @return : the function returns the type of the player
     **/
    int getPlayerType();


    /**
     * @name : getRemoteMove
     * @parameters : an empty move
     * @return : the function reads the move from the server and saves it in 'move'
     **/
    void getRemoteMove(int* move);

private:
    string ip;
    const char* serverIP;
    int port;
    int clientSocket;
};
#endif //CLIENT_H
