/**
 * Limor Levi 308142389
 * Orel Israeli 204225148
 */

#include "HumanPlayer.h"

HumanPlayer::HumanPlayer(enum Type type) : Player(type)
{
    this->type = type;
}
