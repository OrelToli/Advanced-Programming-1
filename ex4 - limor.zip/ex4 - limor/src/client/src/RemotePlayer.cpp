/**
 * Limor Levi 308142389
 * Orel Israeli 204225148
 */

#include "RemotePlayer.h"

RemotePlayer::RemotePlayer(enum Type type) : Player(type)
{
    this->type = type;
}