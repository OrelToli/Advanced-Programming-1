/**
 * Limor Levi 308142389
 * Orel Israeli 204225148
 */

#ifndef REMOTELOGIC_H
#define REMOTELOGIC_H

#include "GameLogic.h"

class RemoteLogic  : public GameLogic {
public:
    /**
     * @name : RemoteLogic
     * @param board - the board of the game
     * @param xPlayer - the x player
     * @param oPlayer - the o player
     * @param printStyle - the display style of the output of the program
     **/
    RemoteLogic(Board *board, Player &xPlayer, Player &oPlayer, Print *printStyle);

  /**
   * @name : remoteMakeMove
   * @param board - the board of the game
   * @param Player - the current player of the game
   * @param printStyle - the display style of the output of the program
   * @param remoteMove - the last move of the remote player
   **/
    void remoteMakeMove(Board &gameBoard, Player &player, Print *printStyle, int *remoteMove);
};
#endif /REMOTELOGIC_H
