/**
 * Limor Levi 308142389
 * Orel Israeli 204225148
 */

#include <gtest/gtest.h>
#include "../src/Board.h"
#include "SquareTests.h"

//test 1: check if comparing two equal squares returns true, and two different squares return false
TEST_F(SquareTests, checkEquation){
    Square s1(1,1,typeX),s2(2,2,typeO),s3(1,1,typeX),s4(1,1,typeO);
    EXPECT_FALSE(s1.equals(s2)) <<"comparing error";
    EXPECT_FALSE(s1.equals(s4)) <<"comparing error";
    EXPECT_TRUE(s1.equals(s3)) <<"comparing error";
}


//test 2: check if specific square is in vector of possible options
TEST_F(SquareTests, isSquareInVector1) {
    Square s1(1,1,typeX),s2(2,2,typeO),s3(5,7,typeX),s4(3,2,typeO),squareToCheck(1,1,typeX);
    vector<Square> options ;
    options.push_back(s1);
    options.push_back(s2);
    options.push_back(s3);
    options.push_back(s4);
    EXPECT_TRUE(squareToCheck.isSquareInVector(options));
}

//test 3: check if specific square is in vector of possible options
TEST_F(SquareTests, isSquareInVector2) {
    Square s1(1,1,typeX),s2(2,2,typeO),s3(5,7,typeX),s4(3,2,typeO),squareToCheck(6,6,typeX);
    vector<Square> options ;
    options.push_back(s1);
    options.push_back(s2);
    options.push_back(s3);
    options.push_back(s4);
    EXPECT_FALSE(squareToCheck.isSquareInVector(options));
}


//test 4: check that every change in square is updated in the entire board
TEST_F(SquareTests, setSquareTypeWorks) {
    this->board.resetBoard();
    this->board.setSquare(4,4,typeO);
    this->board.getSquare(4,4)->setType(typeX);
    EXPECT_TRUE(this->board.getSquareType(4,4)==typeX);
}