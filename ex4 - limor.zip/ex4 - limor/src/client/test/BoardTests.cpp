/**
 * Limor Levi 308142389
 * Orel Israeli 204225148
 */
using namespace std;
#include "../src/Board.h"
#include "../src/DefaultLogic.h"
#include "../src/PrintConsole.h"
#include "BoardTests.h"
#include "../lib/googletest-master/googletest/include/gtest/gtest.h"
#include "../lib/googletest-master/googletest/include/gtest/internal/gtest-internal.h"
#include "../lib/googletest-master/googletest/include/gtest/internal/gtest-port.h"
#include "../lib/googletest-master/googletest/include/gtest/gtest_pred_impl.h"

//test 1: check the existence of 'X' and 'O' in the center of the board
TEST_F(BoardTests, isExistXOInCenter) {
    int location1 = BIGBOARDSIZE / 2 - 1, location2 = BIGBOARDSIZE / 2;
    EXPECT_TRUE(bigBoard.getSquareType(location1,location2) == typeX) <<"incorrect location of O";
    EXPECT_TRUE(bigBoard.getSquareType(location2,location1) == typeX) <<"incorrect location of O";
    EXPECT_TRUE(bigBoard.getSquareType(location1,location1) == typeO) <<"incorrect location of X";
    EXPECT_TRUE(bigBoard.getSquareType(location2,location2) == typeO) <<"incorrect location of X";
}


//test 2: check if the locations of specific squares are in the limits of the board
TEST_F(BoardTests, isSquareInBoard) {
    this->bigBoard.resetBoard();
    int upperBound = BIGBOARDSIZE +1, downBound = 0;
    Square square1(upperBound,upperBound,typeX);
    Square square2(downBound+4, downBound+4,typeX);
    EXPECT_FALSE(bigBoard.isSquareInBoard(square1.getX(),square1.getY())) << "problem with isSquareInBoard function";
    EXPECT_TRUE(bigBoard.isSquareInBoard(square2.getX(),square2.getY())) << "problem with isSquareInBoard function";
}


//test 3:case that changing square in the board isn't happen
TEST_F(BoardTests, setSquareCheck) {
    this->bigBoard.resetBoard();
    bigBoard.setSquare(1,1,typeX);
    EXPECT_EQ(bigBoard.getSquareType(1,1), typeX) << "Incorrect setting of square" ;
}


//test 4: check if copy-constructor works correctly
TEST_F(BoardTests, isCopyBoardOK1) {
    this->bigBoard.resetBoard();
    bigBoard.setSquare(1,1,typeO);
    bigBoard.setSquare(2,2,typeO);
    bigBoard.setSquare(3,3,typeO);
    bigBoard.setSquare(4,4,typeX);
    bigBoard.setSquare(5,5,typeX);
    bigBoard.setSquare(6,6,typeX);
    Board copyBoard(bigBoard);
    EXPECT_TRUE(bigBoard.equals(&copyBoard)) <<"copy constructor isn't correct - the boards aren't equal to each other";
}


//test 4: check if copy-constructor works perfectly
TEST_F(BoardTests, isCopyBoardOK2) {
    this->bigBoard.resetBoard();
    bigBoard.setSquare(0,0,typeO);
    bigBoard.setSquare(2,5,typeO);
    bigBoard.setSquare(4,7,typeO);
    bigBoard.setSquare(3,5,typeX);
    bigBoard.setSquare(5,5,typeX);
    bigBoard.setSquare(2,7,typeX);
    Board copyBoard(bigBoard);
    EXPECT_TRUE(bigBoard.equals(&copyBoard)) <<"copy constructor isn't correct - the boards aren't equal to each other";
}


//test 5:run specific situation on the board,and check that the vector of possible moves is full by the right possible moves
TEST_F(BoardTests, isAvailableMoves1) {
    this->bigBoard.resetBoard();
    PrintConsole printConsole = PrintConsole();
    Print &printStyle = printConsole;
    Player xPlayer = Player(typeX), oPlayer = Player(typeO);
    DefaultLogic dl(&bigBoard, xPlayer, oPlayer,&printStyle);
    bigBoard.setSquare(3,4,typeX);
    bigBoard.setSquare(4,4,typeX);
    bigBoard.setSquare(5,4,typeX);
    bigBoard.setSquare(4,5,typeX);
    bigBoard.setSquare(5,5,typeO);
    vector<Square> options = dl.isAvailableMove(bigBoard, oPlayer);
    EXPECT_TRUE(bigBoard.getSquare(5,3)->isSquareInVector(options)) <<"vector of possible options is not full";
    EXPECT_TRUE(bigBoard.getSquare(3,5)->isSquareInVector(options)) <<"vector of possible options is not full";
    EXPECT_TRUE(bigBoard.getSquare(3,3)->isSquareInVector(options)) <<"vector of possible options is not full";//the example from thr tirgul
    EXPECT_FALSE(bigBoard.getSquare(6,6)->isSquareInVector(options)) <<"vector of possible contain wrong possibles";
    EXPECT_FALSE(bigBoard.getSquare(7,1)->isSquareInVector(options)) <<"vector of possible contain wrong possibles";
    EXPECT_FALSE(bigBoard.getSquare(5,4)->isSquareInVector(options)) <<"vector of possible contain wrong possibles";
}


//test 6:case that the current player doesn't have possible moves
TEST_F(BoardTests, isAvailableMoves2) {
    this->bigBoard.resetBoard();
    PrintConsole printConsole = PrintConsole();
    Print &printStyle = printConsole;
    Player xPlayer = Player(typeX), oPlayer = Player(typeO);
    DefaultLogic dl(&bigBoard, xPlayer, oPlayer,&printStyle);
    bigBoard.setSquare(0,0,typeX);
    bigBoard.setSquare(0,1,typeX);
    bigBoard.setSquare(0,2,typeX);
    bigBoard.setSquare(0,3,typeX);
    bigBoard.setSquare(0,4,typeX);
    bigBoard.setSquare(0,5,typeX);
    bigBoard.setSquare(0,6,typeO);
    bigBoard.setSquare(0,7,typeX);
    vector<Square> options = dl.isAvailableMove(bigBoard, oPlayer);
    EXPECT_EQ(options.size(),0) <<"vector of possible moves contain possible moves when it suppose to be empty";
}


//test 7: case that one square of the first player is surrounded  by squares of the enemy from every direction - many possible moves
TEST_F(BoardTests, isAvailableMoves3) {
    this->bigBoard.resetBoard();
    PrintConsole printConsole = PrintConsole();
    Print &printStyle = printConsole;
    Player xPlayer = Player(typeX), oPlayer = Player(typeO);
    DefaultLogic dl(&bigBoard, xPlayer, oPlayer,&printStyle);
    bigBoard.setSquare(4,3,typeX);
    bigBoard.setSquare(3,2,typeO);
    bigBoard.setSquare(4,2,typeO);
    bigBoard.setSquare(5,2,typeO);
    bigBoard.setSquare(3,3,typeO);
    bigBoard.setSquare(5,3,typeO);
    bigBoard.setSquare(3,2,typeO);
    bigBoard.setSquare(3,4,typeO);
    bigBoard.setSquare(4,4,typeO);
    bigBoard.setSquare(5,4,typeO);
    vector<Square> options = dl.isAvailableMove(bigBoard, xPlayer);
    EXPECT_TRUE(bigBoard.getSquare(2,1)->isSquareInVector(options)) <<"vector of possible options is not full";
    EXPECT_TRUE(bigBoard.getSquare(4,1)->isSquareInVector(options)) <<"vector of possible options is not full";
    EXPECT_TRUE(bigBoard.getSquare(6,1)->isSquareInVector(options)) <<"vector of possible options is not full";
    EXPECT_TRUE(bigBoard.getSquare(2,5)->isSquareInVector(options)) <<"vector of possible options is not full";
    EXPECT_TRUE(bigBoard.getSquare(4,5)->isSquareInVector(options)) <<"vector of possible options is not full";
    EXPECT_TRUE(bigBoard.getSquare(6,5)->isSquareInVector(options)) <<"vector of possible options is not full";
    EXPECT_TRUE(bigBoard.getSquare(2,3)->isSquareInVector(options)) <<"vector of possible options is not full";
    EXPECT_TRUE(bigBoard.getSquare(6,3)->isSquareInVector(options)) <<"vector of possible options is not full";
}


//test 8:check if getSquareType function is correct and returns the right type
TEST_F(BoardTests, getSquareCorrect) {
    this->bigBoard.resetBoard();
    Square s(2,2,typeX);
    this->bigBoard.setSquare(2,2,typeX);
    EXPECT_EQ(s.getType(),this->bigBoard.getSquareType(2,2));
}


//test 9:check if specific location is in the board limits
TEST_F(BoardTests, isSquareInBoard1) {
    this->bigBoard.resetBoard();
    EXPECT_TRUE(this->bigBoard.isSquareInBoard(7,7));
}


//test 10: check negative coordinates of location of square - nust be out of bounds of the board
TEST_F(BoardTests, isSquareInBoard2) {
    this->bigBoard.resetBoard();
    EXPECT_FALSE(this->bigBoard.isSquareInBoard(-1,2));
}



