/**
 * Limor Levi 308142389
 * Orel Israeli 204225148
 */
#ifndef SQUARETESTS_H
#define SQUARETESTS_H



#include <gtest/gtest.h>
#include "../src/Board.h"

#define BOARDSIZE 8


class SquareTests : public testing::Test{
public:
    Board board;
    SquareTests(): board(BOARDSIZE){}

};

#endif //SQUARETESTS_H
