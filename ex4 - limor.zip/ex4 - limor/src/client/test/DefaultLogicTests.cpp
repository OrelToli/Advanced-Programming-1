/**
 * Limor Levi 308142389
 * Orel Israeli 204225148
 */
using namespace std;
#include <gtest/gtest.h>
#include "../src/Board.h"
#include "../src/DefaultLogic.h"
#include "DefaultLogicTests.h"
#include "../lib/googletest-master/googletest/include/gtest/gtest.h"
#include "../lib/googletest-master/googletest/include/gtest/internal/gtest-internal.h"
#include "../lib/googletest-master/googletest/include/gtest/gtest_pred_impl.h"
#include "../lib/googletest-master/googletest/include/gtest/internal/gtest-port.h"


//Test1
//Creates a game that should end due to full board, checks if the gameOver function decides that the game is over.
TEST_F(DefaultLogicTests, GameOverWhenFullBoard) {

    this->smallBoard.resetBoard();

    smallBoard.setSquare(0,0,typeX);
    smallBoard.setSquare(0,0,typeX);
    smallBoard.setSquare(0,2,typeX);
    smallBoard.setSquare(1,0,typeX);
    smallBoard.setSquare(1,1,typeX);
    smallBoard.setSquare(1,2,typeX);
    smallBoard.setSquare(2,0,typeX);
    smallBoard.setSquare(2,1,typeX);
    smallBoard.setSquare(2,2,typeX);

    EXPECT_TRUE(dSmall.gameOver()) << "GameOverWhenFullBoard smallBoard Failed";

    this->bigBoard.resetBoard();
    for (int i = 0; i < bigBoard.getBoardSize(); i++) {
        for (int j = 0; j < bigBoard.getBoardSize(); j++) {
            bigBoard.setSquare(i,j,typeX);
        }
    }

    EXPECT_TRUE(dBig.gameOver()) << "GameOverWhenFullBoard bigBoard Failed";
}

//Test2
//Checks if the game is over when no more moves are available.
TEST_F(DefaultLogicTests, GameOverWhenNoMoreMoves) {
    this->smallBoard.resetBoard();

    smallBoard.setSquare(0,1,typeO);
    smallBoard.setSquare(1,0,typeX);
    smallBoard.setSquare(1,1,typeX);
    smallBoard.setSquare(1,2,typeO);
    smallBoard.setSquare(2,1,typeX);
    EXPECT_TRUE(dSmall.gameOver()) << "GameOverWhenNoMoreMoves smallBoard 1 Failed";

    this->smallBoard.resetBoard();

    smallBoard.setSquare(0,0,typeO);
    smallBoard.setSquare(2,0,typeO);
    smallBoard.setSquare(2,0,typeO);
    smallBoard.setSquare(2,2,typeO);
    smallBoard.setSquare(1,1,typeX);

    EXPECT_TRUE(dSmall.gameOver()) << "GameOverWhenNoMoreMoves smallBoard 2 Failed";
}


//Test 3:
//Checks that all possible moves are as they should be.
TEST_F(DefaultLogicTests, AvailableMovesAreAsExpected) {

    this->bigBoard.resetBoard();

    int movesCounter = 0;
    vector<Square> excpectedAvailableMoves;
    excpectedAvailableMoves.push_back(Square(1,3,typeX));
    excpectedAvailableMoves.push_back(Square(2,4,typeX));
    excpectedAvailableMoves.push_back(Square(3,1,typeX));
    excpectedAvailableMoves.push_back(Square(3,5,typeX));
    excpectedAvailableMoves.push_back(Square(5,1,typeX));
    excpectedAvailableMoves.push_back(Square(5,2,typeX));
    excpectedAvailableMoves.push_back(Square(5,3,typeX));

    bigBoard.setSquare(2,2,typeX);
    bigBoard.setSquare(2,3,typeO);
    bigBoard.setSquare(3,2,typeO);
    bigBoard.setSquare(3,3,typeX);
    bigBoard.setSquare(3,4,typeO);
    bigBoard.setSquare(4,2,typeO);
    bigBoard.setSquare(4,3,typeO);

    vector<Square> options = dBig.isAvailableMove(bigBoard, xPlayer);
    EXPECT_EQ(excpectedAvailableMoves.size(),options.size()) << "AvailableMovesAreAsExpected Failed - Vector Size";

    for( vector<Square>::iterator it=options.begin();it!=options.end();it++)
        for( vector<Square>::iterator it2=excpectedAvailableMoves.begin();it2!=excpectedAvailableMoves.end();it2++)
            if((*it).isSameLocation((*it2)))
                movesCounter++;


    EXPECT_EQ(movesCounter,options.size()) << "AvailableMovesAreAsExpected Failed - Not all the moves exist";
    options.clear();
    excpectedAvailableMoves.clear();
}



//Test 4:
//Make sure that all the right squares are changed when a move is made.
TEST_F(DefaultLogicTests, PlayerMoveEatsOtherPlayerSquaresCorrectly) {

    bool allCirclesFlipped = false;
    this->smallBoard.resetBoard();

    //Eating at 3,1
    smallBoard.setSquare(0,0,typeX);
    smallBoard.setSquare(1,0,typeO);
    smallBoard.setSquare(1,1,typeO);
    smallBoard.setSquare(2,1,typeO);
    smallBoard.setSquare(0,2,typeX);
    smallBoard.setSquare(2,2,typeX);


    dSmall.makeMove(xPlayer,smallBoard,2,0);
    if(smallBoard.getSquareType(1,0) == typeX && smallBoard.getSquareType(1,1) == typeX && smallBoard.getSquareType(2,1) == typeX)
        allCirclesFlipped = true;

    EXPECT_TRUE(allCirclesFlipped) << "PlayerMoveEatsOtherPlayerSquaresCorrectly smallBoard Failed";


    allCirclesFlipped = false;
    this->bigBoard.resetBoard();

    bigBoard.setSquare(2,3,typeO);
    bigBoard.setSquare(4,3,typeO);
    bigBoard.setSquare(3,3,typeX);
    bigBoard.setSquare(2,4,typeX);
    bigBoard.setSquare(3,4,typeX);
    bigBoard.setSquare(4,4,typeX);

    dBig.makeMove(oPlayer,bigBoard,2,5);
    if(bigBoard.getSquareType(2,4) == typeO && bigBoard.getSquareType(3,4) == typeO)
        allCirclesFlipped = true;
    EXPECT_TRUE(allCirclesFlipped) << "PlayerMoveEatsOtherPlayerSquaresCorrectly bigBoard Failed";
}


//Test 5:
//Checks that a token of "NO POSSIBLE MOVES" is thrown once no moves are available.
TEST_F(DefaultLogicTests, NoPossibleMovesAvailable) {
    this->smallBoard.resetBoard();

    smallBoard.setSquare(0,0,typeO);
    smallBoard.setSquare(0,1,typeO);
    smallBoard.setSquare(1,0,typeX);
    smallBoard.setSquare(1,1,typeO);
    smallBoard.setSquare(1,2,typeX);
    smallBoard.setSquare(2,1,typeX);
    vector<Square> options = dSmall.isAvailableMove(smallBoard, xPlayer);


    EXPECT_TRUE(options.empty()) << "NoPossibleMovesAvailable Failed";
}



//Test 6:
//Checks that the winner is chosen correctly once the game is over.
TEST_F(DefaultLogicTests, WhenGameOverTheRightPlayerWins) {

    this->smallBoard.resetBoard();

    Type expectedWinner = typeO;

    smallBoard.setSquare(0,1,typeO);
    smallBoard.setSquare(0,2,typeO);
    smallBoard.setSquare(1,1,typeX);
    smallBoard.setSquare(1,2,typeO);

    EXPECT_EQ(dSmall.checkWhoWins(&smallBoard),expectedWinner) << "WhenGameOverTheRightPlayerWins smallBoard Failed";


    this->bigBoard.resetBoard();

    expectedWinner = typeX;
    bigBoard.setSquare(0,1,typeX);
    bigBoard.setSquare(0,2,typeX);
    bigBoard.setSquare(1,1,typeO);
    bigBoard.setSquare(1,2,typeX);
    EXPECT_EQ(dBig.checkWhoWins(&bigBoard),expectedWinner) << "WhenGameOverTheRightPlayerWins bigBoard Failed";
}


//Test 7:
//Makes sure that the AI chooses the best move out of the available moves to play.
TEST_F(DefaultLogicTests, AIChoosesTheBestMoveAvailable) {

    this->bigBoard.resetBoard();

    bigBoard.setSquare(4,4,typeX);
    bigBoard.setSquare(4,5,typeX);
    bigBoard.setSquare(5,4,typeX);
    bigBoard.setSquare(5,5,typeO);
    bigBoard.setSquare(3,4,typeX);

    dBig.makeMoveAI(bigBoard, oPlayer);

    Square bestOption1 = Square(3,3,typeO);
    Square bestOption2 = Square(5,3,typeO);

    bool excpectedMoveCompleted = (bigBoard.getSquareType(bestOption1.getX(),bestOption1.getY()) == bestOption1.getType()
        || bigBoard.getSquareType(bestOption2.getX(),bestOption2.getY()) == bestOption2.getType());
    EXPECT_TRUE(excpectedMoveCompleted) << "AIChoosesTheBestMoveAvailable Test 1 Failed";

    this->bigBoard.resetBoard();

    bigBoard.setSquare(2,3,typeO);
    bigBoard.setSquare(4,3,typeO);
    bigBoard.setSquare(3,3,typeX);
    bigBoard.setSquare(2,4,typeX);
    bigBoard.setSquare(3,4,typeX);
    bigBoard.setSquare(4,4,typeX);
    dBig.makeMoveAI(bigBoard, oPlayer);

    bestOption1 = Square(2,5,typeO);

    excpectedMoveCompleted = (bigBoard.getSquareType(bestOption1.getX(),bestOption1.getY()) == bestOption1.getType());
    EXPECT_TRUE(excpectedMoveCompleted) << "AIChoosesTheBestMoveAvailable Test 1 Failed";
}


//Test 8:
//Checks that the minMax algorithm works perfectly and returns the max points that the X player can get.
TEST_F(DefaultLogicTests, AIAlgorithmCalculatesMaxPointsFromMovesOfUserPlayerCorrectly) {


    this->bigBoard.resetBoard();
    int maxPointsForAIMove = 0;
    int expectedMaxPoints = 3;

    bigBoard.setSquare(4,4,typeX);
    bigBoard.setSquare(4,5,typeX);
    bigBoard.setSquare(5,4,typeX);
    bigBoard.setSquare(5,5,typeO);
    bigBoard.setSquare(3,4,typeX);

    Square currentAIMove = Square(3,3,typeO);
    maxPointsForAIMove = dBig.moveWithMinimalHumanPlayerPoints(currentAIMove,bigBoard);

    EXPECT_EQ(maxPointsForAIMove,expectedMaxPoints)
                        << "AIAlgorithmCalculatesMaxPointsFromMovesOfUserPlayerCorrectly Test 1 Failed";

    this->bigBoard.resetBoard();
    expectedMaxPoints = 2;

    bigBoard.setSquare(2,3,typeO);
    bigBoard.setSquare(4,3,typeO);
    bigBoard.setSquare(3,3,typeX);
    bigBoard.setSquare(2,4,typeX);
    bigBoard.setSquare(3,4,typeX);
    bigBoard.setSquare(4,4,typeX);

    currentAIMove = Square(4,5,typeO);
    maxPointsForAIMove = dBig.moveWithMinimalHumanPlayerPoints(currentAIMove,bigBoard);

    EXPECT_EQ(maxPointsForAIMove,expectedMaxPoints)
                        << "AIAlgorithmCalculatesMaxPointsFromMovesOfUserPlayerCorrectly Test 2 Failed";
}


