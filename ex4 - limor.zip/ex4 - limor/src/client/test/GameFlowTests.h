/**
 * Limor Levi 308142389
 * Orel Israeli 204225148
 */

#ifndef GAMEFLOWTESTS_H
#define GAMEFLOWTESTS_H

#include <gtest/gtest.h>
#include "../src/Board.h"
#include "../src/PrintConsole.h"
#define BOARDSIZE 3


class GameFlowTests : public testing::Test{
public:
    Board board;
    Player xPlayer;
    Player oPlayer;
    PrintConsole printConsole;
    DefaultLogic defaultLogic;
    GameFlow gameFlow;
    GameFlowTests(): board(BOARDSIZE), xPlayer(typeX), oPlayer(typeO), printConsole(),
                     defaultLogic(&board,xPlayer,oPlayer,&printConsole),
                     gameFlow(&defaultLogic,&board,xPlayer,oPlayer,&printConsole) {}
};

#endif //GAMEFLOWTESTS_H
