/**
 * Limor Levi 308142389
 * Orel Israeli 204225148
 */

using namespace std;
#include <gtest/gtest.h>
#include "../src/Board.h"
#include "../src/DefaultLogic.h"
#include "../src/GameFlow.h"
#include "GameFlowTests.h"
#include "../lib/googletest-master/googletest/include/gtest/gtest.h"
#include "../lib/googletest-master/googletest/include/gtest/internal/gtest-internal.h"
#include "../lib/googletest-master/googletest/include/gtest/gtest_pred_impl.h"
#include "../lib/googletest-master/googletest/include/gtest/internal/gtest-port.h"


/**We didn't write many tests for this class because most of the class's operations are according to the user input
 and depends on it. So we checked only the parts that we are responsible for and this is the
 switching turns between the players. The rest of the operations performed in this class were tested
 in the other test classes (such as DefaultLogicTests)
**/

//test 1: ensure that the turn exchanges works
TEST_F(GameFlowTests, TurnsChangeCorrectly) {
    board.resetBoard();
    bool flag = true;
    bool firstTurn,secondTurn;
    Player &current = xPlayer;
    gameFlow.changeTurn(current,flag);
    firstTurn = (current.getType() == oPlayer.getType());
    gameFlow.changeTurn(current,flag);
    secondTurn = (current.getType() == xPlayer.getType());

    EXPECT_EQ(firstTurn,secondTurn);
}


